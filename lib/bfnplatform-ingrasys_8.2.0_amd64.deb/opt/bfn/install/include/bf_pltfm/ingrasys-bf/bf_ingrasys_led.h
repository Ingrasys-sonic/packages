#ifndef _BF_INGRASYS_LED_H
#define _BF_INGRASYS_LED_H
#ifdef INC_PLTFM_UCLI
#include <bfutils/uCli/ucli.h>
#endif

#include "bf_pltfm_led.h"

/* led blink will delay 2 seconds for polling */
#define BLINK_LED_DELAY_USEC 2000000

#define VERB_LED_DEBUG       0

/*
 * enable led blink timer task
 */
#define LED_BLINK_TIMER      1

/*
 * ingrasys common
 */

/* display port led using tofino stateout buffer */
int bf_pltfm_port_led_by_cpld_set(int chip_id,
                                  bf_pltfm_port_info_t *port_info,
                                  int led_col,
                                  bf_led_blink_t led_blink);

/* set port blink led bitmap */
void bf_pltfm_ingresys_s9280_set_blink_bitmap(
                                  int port, int chnl, 
                                  bf_led_blink_t led_blink);

/* apply port blink led bitmap to cpld via sysfs */
int bf_pltfm_ingresys_s9280_apply_blink_bitmap(void);

int s9280_led_blink_bitmap_init(int chip_id);


#ifdef INC_PLTFM_UCLI
ucli_node_t *bf_pltfm_led_ucli_node_create(ucli_node_t *m);
#endif

#endif /* _BF_PLTFM_INGRASYS_LED_H */
