/**************************************************************************//**
 *
 * x86_64_ingrasys_s9180_32x Doxygen Header
 *
 *****************************************************************************/
#ifndef __x86_64_ingrasys_s9180_32x_DOX_H__
#define __x86_64_ingrasys_s9180_32x_DOX_H__

/**
 * @defgroup x86_64_ingrasys_s9180_32x x86_64_ingrasys_s9180_32x - x86_64_ingrasys_s9180_32x Description
 *

The documentation overview for this module should go here.

 *
 * @{
 *
 * @defgroup x86_64_ingrasys_s9180_32x-x86_64_ingrasys_s9180_32x Public Interface
 * @defgroup x86_64_ingrasys_s9180_32x-config Compile Time Configuration
 * @defgroup x86_64_ingrasys_s9180_32x-porting Porting Macros
 *
 * @}
 *
 */

#endif /* __x86_64_ingrasys_s9180_32x_DOX_H__ */
