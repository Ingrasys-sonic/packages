#!/usr/bin/env python

try:
    from sonic_sfp.sfputilbase import sfputilbase
except ImportError, e:
    raise ImportError (str(e) + "- required module not found")


class sfputil(sfputilbase):
    """Platform specific sfputil class"""

    port_start = 0
    port_end = 31
    ports_in_block = 32

    port_to_eeprom_mapping = {}
    #TODO: modify according to port map
    port_to_i2c_mapping = {
        0: 21,
        1: 22,
        2: 23,
        3: 24,
        4: 25,
        5: 26,
        6: 27,
        7: 28,
        8: 29,
        9: 30,
        10: 31,
        11: 32,
        12: 33,
        13: 34,
        14: 35,
        15: 36,
        16: 37,
        17: 38,
        18: 39,
        19: 40,
        20: 41,
        21: 42,
        22: 43,
        23: 44,
        24: 45,
        25: 46,
        26: 47,
        27: 48,
        28: 49,
        29: 50,
        30: 51,
        31: 52
    }

    _qsfp_ports = range(0, ports_in_block + 1)

    def __init__(self, port_num):
        # Override port_to_eeprom_mapping for class initialization
        eeprom_path = '/sys/class/i2c-adapter/i2c-{0}/{0}-0050/eeprom'
        for x in range(self.port_start, self.port_end + 1):
            port_eeprom_path = eeprom_path.format(self.port_to_i2c_mapping[x])
            self.port_to_eeprom_mapping[x] = port_eeprom_path
        sfputilbase.__init__(self, port_num)
